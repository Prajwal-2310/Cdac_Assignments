import java.util.Scanner;

class sumOfTwoNumbers{
	public int sum(int num1,int num2){

	int sum = 0;
	sum = num1 + num2;
	return sum;
	}
	
}

public class addition{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the first number: ");
		int num1 = sc.nextInt();
		System.out.print("Enter the second number: ");
		int num2 = sc.nextInt();

		sumOfTwoNumbers add = new sumOfTwoNumbers();
		
		int result = add.sum(num1,num2);
		
		System.out.println("The addition of two numbers: "+ result);

	}
}