import java.util.Scanner;

class AskForPositiveNo {

    static void positive() {

        Scanner sc = new Scanner(System.in);
        int num;

        do {
            System.out.print("Enter a positive number: ");
            num = sc.nextInt();

        } while (num <= 0);

        System.out.println("The number is a positive number: " + num);
    }

    public static void main(String[] args) {

        positive();
    }
}