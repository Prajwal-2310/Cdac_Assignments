import java.util.Scanner;

public class table{
	
	static void printMultiTable(int num){
		for(int i=1; i<=10; i++){
			System.out.println(num * i);
		}
	}
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number for table: ");
		int num = sc.nextInt();
		System.out.println("The table of "+num+" is:");
		printMultiTable(num);
	}

}