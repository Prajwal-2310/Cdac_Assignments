import java.util.Scanner;

public class MenuDriven{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your choice: ");
		int choice = sc.nextInt();

		switch(choice){
		
		case 1:
			int Math = 80;
		int Science = 85;
		int History = 90;
		
		int average = (Math + Science + History) / 3;
		
		if(average >= 90){
			System.out.println("Grade A");

		}else if(average <= 89  && average >= 70){
		
			System.out.println("Grade B");
		}else if(average <= 69 && average >= 50){
		
			System.out.println("Grade D");
		}else if(average <= 49 && average >= 30){
		
			System.out.println("Grade D");
		}else{

			System.out.println("Fail");
		}
		
		break;

		case 2:
			 int year = 2004;

       			 if (year % 4 == 0 && year %100 !=0 || year % 400 == 0) {
          			  System.out.println(year + " is Leap Year");
     			 } else {
           			  System.out.println(year + " is not Leap Year");
        	         }

			 break;





		case 3:
			 int day = 3;

        switch (day) {
            case 1:
                System.out.println("Monday");
                break;

            case 2:
                System.out.println("Tuesday");
                break;

            case 3:
                System.out.println("Wensday");
                break;

            case 4:
                System.out.println("Thusday");
                break;

            case 5:
                System.out.println("Friday");
                break;

            case 6:
                System.out.println("Saturday");
                break;

            case 7:
                System.out.println("Sunday");
                break;
        
            default:
                System.out.println("Invalid day number");
                break;
        }
		break;




	case 4:
		byte a = 110;
		System.out.println(a);

		short b = 320;
		System.out.println(b);

		int c = 10000;
		System.out.println(c);

		long d = 264786;
		System.out.println(d);

		float e = 1.26f;
		System.out.println(e);

		double f = 1.465257654d;
		System.out.println(f);

		char g = 'p';
		System.out.println(g);

		Boolean h = true;
		System.out.println(h);

		break;






		}
	
	}

}