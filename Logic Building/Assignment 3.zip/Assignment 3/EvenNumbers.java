import java.util.Scanner;

public class EvenNumbers{

	static void even(){
		int i = 1;
		while(i <= 50){
			if(i % 2==0){
				System.out.print(i+" ");
				
			}
			i++;
		}
	}


	public static void main(String[] args){
		
		
		System.out.print("Even numbers from 1 to 50 are: ");
		even();
	}

}