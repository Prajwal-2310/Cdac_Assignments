public class StringIntern{
    public static void main(String[] args) {
        
        String str1 = new String("Prajwal");
        String str2 = str1.intern();
        String str3 = "Prajwal";

        System.out.print(str2 == str3);
    }
}