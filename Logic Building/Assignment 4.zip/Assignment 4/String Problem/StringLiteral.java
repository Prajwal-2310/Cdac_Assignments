public class StringLiteral {
    public static void main(String[] args) {
        
        String str1 = "Hello";
        String str2 = "Hello";

        System.out.print("Both variables points to the same object"+str1 == str2);
    }
}
