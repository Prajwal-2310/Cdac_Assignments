public class MultipleString {
    public static void main(String[] args) {
        
        String str1 = "Prajwal";
        String str2 = "Prajwal";
        String str3 = "Prajwal";

        System.out.println(str1 == str2);
        System.out.println(str1 == str3);
        System.out.println(str2 == str3);
    }
}
