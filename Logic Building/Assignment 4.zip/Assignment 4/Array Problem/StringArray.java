import java.util.Scanner;

public class StringArray{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a String array:");
		String[] arr = new String[4];

		for(int i=0; i<4; i++){
			arr[i] = sc.nextLine();
		}
		System.out.println("The string array are: ");
		for(int i=0; i<4; i++){
			System.out.println(arr[i]);
		}
	}

}