import java.util.Scanner;

public class largest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an array element");
        int arr[] = new int[5];
        for(int i = 0; i<5; i++){
            arr[i] = sc.nextInt();
        }

        int largest = arr[0];
        for(int i = 0; i<5; i++){
            if (arr[i]>largest) {
                largest = arr[i];
            }
        }
        

        System.out.print("Largest element in an array is:"+largest);
        
    }
}
