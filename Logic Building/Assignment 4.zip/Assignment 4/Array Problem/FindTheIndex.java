import java.util.Scanner;
import java.util.Arrays;


public class FindTheIndex{
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        System.out.println("Enter an array element");
        int arr[] = new int[5];
        for(int i = 0; i<5; i++){
            arr[i] = sc.nextInt();
        }
	System.out.print("Enter a number to be searched:");
	int num = sc.nextInt();

	int index = Arrays.binarySearch(arr, num);
       
	System.out.println( num+" is found at index: "+index);
	

    }
}