import java.util.Scanner;

public class PrintArray{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter an array elemnts:");
		
		int arr[] = new int[5];
		for(int i=0; i<5; i++){
			arr[i] = sc.nextInt();
		}
		
		System.out.println("The elements of an array are:");
		for(int i=0; i<arr.length; i++){
			System.out.print(arr[i]+" ");
		}
	}
}