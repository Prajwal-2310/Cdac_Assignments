import java.util.Scanner;
import java.util.Arrays;


public class AscendeingOrder{
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        System.out.println("Enter an array element");
        int arr[] = new int[5];
        for(int i = 0; i<5; i++){
            arr[i] = sc.nextInt();
        }
	Arrays.sort(arr);
       
	System.out.println("After sorting an array: "+Arrays.toString(arr));
	

    }
}