import java.util.Scanner;

public class positiveNegative{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an array element");
        int arr[] = new int[6];
        for(int i = 0; i<6; i++){
            arr[i] = sc.nextInt();
        }
	
	int positive = 0;
	int negative = 0;

        for(int i = 0; i<6; i++){
           if(arr[i] > 0){
		positive++;
		}else if(arr[i] < 0){
		negative++;
		}
        }

        
        System.out.println("The count of positive elements in an array is "+positive);
	System.out.println("The count of negative elements in an array is "+negative);
        
    }
}
