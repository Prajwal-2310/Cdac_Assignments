import java.util.Scanner;
import java.util.Arrays;


public class FoundSpecificElement{
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        System.out.println("Enter an array element:");
        Integer arr[] = new Integer[5];
        for(int i = 0; i<5; i++){
            arr[i] = sc.nextInt();
        }
	
	System.out.print("Enter a number to be searched:");
	int num = sc.nextInt();
	
	if(Arrays.asList(arr).contains(num)){
		System.out.println("Number is Found");
	}else{
		System.out.println("Number is not found");
	}
	
	

    }
}