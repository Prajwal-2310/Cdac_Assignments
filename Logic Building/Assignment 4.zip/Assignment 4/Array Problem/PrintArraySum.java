import java.util.Scanner;

public class PrintArraySum{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter an array elemnts:");
		
		int arr[] = new int[5];
		for(int i=0; i<5; i++){
			arr[i] = sc.nextInt();
		}

		int sum = 0;
		for(int i=0; i<arr.length; i++){
			sum = sum + arr[i];
			
		}
		System.out.print("The sum of an elements of an array is:"+sum);
	}
}