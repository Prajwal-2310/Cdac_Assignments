import java.util.Scanner;

public class average {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an array element");
        int arr[] = new int[5];
        for(int i = 0; i<5; i++){
            arr[i] = sc.nextInt();
        }

        int sum = 0;
        for(int i = 0; i<5; i++){
           sum = sum + arr[i];
        }

	int average = sum / 5;
        

        System.out.print("Average of elements of an array is:"+average);
        
    }
}
