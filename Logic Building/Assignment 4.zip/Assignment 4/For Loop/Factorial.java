import java.util.Scanner;

public class Factorial{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int N = sc.nextInt();
		
		int fact = 1;
		for(int i=N; i>=1; i--){
			fact = fact * i;
		}
		System.out.println("The factorial of "+N+" is "+ fact);
	}
}