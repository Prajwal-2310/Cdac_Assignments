import java.util.Scanner;

public class EvenNumbers{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int N = sc.nextInt();
		
		System.out.println("Even numbers from 1 to N are:");
		for(int i=1; i<=N; i++){
			if(i % 2 == 0)
				System.out.print(i+" ");
		}
	}
}