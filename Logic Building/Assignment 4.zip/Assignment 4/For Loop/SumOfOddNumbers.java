import java.util.Scanner;

public class SumOfOddNumbers{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int N = sc.nextInt();
		
		int sum = 0;
		
		for(int i=1; i<=N; i++){
			if(i % 2 != 0){
				sum = sum + i;	
			}
		}
		System.out.print("The sum of 1 to N odd number is:"+sum);
	}
}